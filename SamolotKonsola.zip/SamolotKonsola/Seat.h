#ifndef SEAT_H
#define SEAT_H

#include <string>

enum SeatStatus { AVAILABLE, OCCUPIED, SELECTED };

struct Seat {
    std::string id;
    SeatStatus status;
};

#endif // SEAT_H