#include "ConsoleUI.h"
#include <iostream>
#include <cctype>

ConsoleUI::ConsoleUI(Airplane& plane) : airplane(plane) {}

void ConsoleUI::toUpperString(std::string& str) const {
    for (char& c : str) {
        c = toupper(c);
    }
}

void ConsoleUI::displaySeats() const {
    std::cout << "\n=== UKLAD MIEJSC W SAMOLOCIE ===\n";
    std::cout << "Legenda: [ ] Wolne | [X] Zajete | [*] Twoje miejsce\n\n";
    std::cout << "    A   B   C       D   E   F\n";

    const auto& seats = airplane.getSeats();
    int rows = airplane.getNumRows();

    for (int i = 0; i < rows; ++i) {
        if (i + 1 < 10) std::cout << " ";
        std::cout << i + 1 << " ";

        for (int j = 0; j < 6; ++j) {
            if (seats[i][j].status == AVAILABLE) std::cout << "[ ] ";
            else if (seats[i][j].status == OCCUPIED) std::cout << "[X] ";
            else if (seats[i][j].status == SELECTED) std::cout << "[*] ";

            if (j == 2) std::cout << "   ";
        }
        std::cout << "\n";
    }
    std::cout << "\n";
}

void ConsoleUI::displaySelectedSeats() const {
    std::vector<std::string> currentSeats = airplane.getSelectedSeats();
    
    std::cout << "Aktualnie wybrane miejsca: ";
    if (currentSeats.empty()) {
        std::cout << "Brak\n";
    } else {
        for (size_t i = 0; i < currentSeats.size(); ++i) {
            std::cout << currentSeats[i];
            if (i < currentSeats.size() - 1) std::cout << ", ";
        }
        std::cout << "\n";
    }
}

void ConsoleUI::handleSeatSelectionResult(SelectResult result, const std::string& seatId) const {
    switch (result) {
        case SelectResult::SUCCESS_ADDED:
            std::cout << "--- Dodano miejsce " << seatId << " do rezerwacji ---\n";
            break;
        case SelectResult::SUCCESS_REMOVED:
            std::cout << "--- Odznaczono miejsce " << seatId << " ---\n";
            break;
        case SelectResult::ERROR_OCCUPIED:
            std::cout << "--- BLAD: To miejsce jest juz zajete! ---\n";
            break;
        case SelectResult::ERROR_INVALID:
            std::cout << "--- BLAD: Nieprawidlowy numer miejsca (np. wpisz 1A albo 5C). ---\n";
            break;
    }
}

void ConsoleUI::run() {
    std::string input;
    std::cout << "Witaj w terminalu rezerwacji biletow lotniczych!\n";

    while (true) {
        displaySeats();
        displaySelectedSeats();

        std::cout << "\nWpisz numer miejsca (np. 3B) aby je ZAZNACZYC/ODZNACZYC,\n'Z' aby ZATWIERDZIC lub 'W' aby WYJSC: ";
        std::cin >> input;
        
        toUpperString(input);

        if (input == "W") {
            std::cout << "\nPrzerwano rezerwacje. Do widzenia!\n";
            break;
        } else if (input == "Z") {
            auto currentSeats = airplane.getSelectedSeats();
            if (currentSeats.empty()) {
                std::cout << "\n*** MUSISZ WYBRAC PRZYNAJMNIEJ JEDNO MIEJSCE PRZED ZATWIERDZENIEM! ***\n";
            } else {
                std::cout << "\n=============================================\n";
                std::cout << "SUKCES! Zarezerwowano miejsca: ";
                for (size_t i = 0; i < currentSeats.size(); ++i) {
                    std::cout << currentSeats[i];
                    if (i < currentSeats.size() - 1) std::cout << ", ";
                }
                std::cout << ".\nMilego lotu!\n";
                std::cout << "=============================================\n";
                break;
            }
        } else {
            SelectResult result = airplane.toggleSeat(input);
            handleSeatSelectionResult(result, input);
        }
    }
}