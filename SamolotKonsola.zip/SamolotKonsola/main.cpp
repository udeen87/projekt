#include "Airplane.h"
#include "ConsoleUI.h"

int main() {

    Airplane flight(10);


    ConsoleUI ui(flight);

    ui.run();

    return 0;
}