#include "Airplane.h"
#include <cstdlib>
#include <ctime>
#include <algorithm>

Airplane::Airplane(int rows) : numRows(rows) {
    initializeSeats();
}

void Airplane::initializeSeats() {
    srand(static_cast<unsigned>(time(0)));
    std::vector<char> cols = {'A', 'B', 'C', 'D', 'E', 'F'};

    for (int i = 1; i <= numRows; ++i) {
        std::vector<Seat> row;
        for (char c : cols) {
            Seat s;
            s.id = std::to_string(i) + c;
            s.status = (rand() % 100 < 30) ? OCCUPIED : AVAILABLE;
            row.push_back(s);
        }
        seats.push_back(row);
    }
}

SelectResult Airplane::toggleSeat(const std::string& seatId) {
    for (int i = 0; i < numRows; ++i) {
        for (int j = 0; j < 6; ++j) {
            if (seats[i][j].id == seatId) {

                if (seats[i][j].status == OCCUPIED) {
                    return SelectResult::ERROR_OCCUPIED;
                }


                if (seats[i][j].status == SELECTED) {
                    seats[i][j].status = AVAILABLE;
                    currentlySelectedSeats.erase(
                        std::remove(currentlySelectedSeats.begin(), currentlySelectedSeats.end(), seatId),
                        currentlySelectedSeats.end()
                    );
                    return SelectResult::SUCCESS_REMOVED;
                }

                else {
                    seats[i][j].status = SELECTED;
                    currentlySelectedSeats.push_back(seatId);
                    return SelectResult::SUCCESS_ADDED;
                }
            }
        }
    }
    return SelectResult::ERROR_INVALID;
}

int Airplane::getNumRows() const {
    return numRows;
}

const std::vector<std::vector<Seat>>& Airplane::getSeats() const {
    return seats;
}

std::vector<std::string> Airplane::getSelectedSeats() const {
    return currentlySelectedSeats;
}