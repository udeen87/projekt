#ifndef AIRPLANE_H
#define AIRPLANE_H

#include <vector>
#include <string>
#include "Seat.h"


enum class SelectResult { SUCCESS_ADDED, SUCCESS_REMOVED, ERROR_OCCUPIED, ERROR_INVALID };

class Airplane {
private:
    int numRows;
    std::vector<std::vector<Seat>> seats;
    std::vector<std::string> currentlySelectedSeats;

    void initializeSeats();

public:
    Airplane(int rows);


    SelectResult toggleSeat(const std::string& seatId);


    int getNumRows() const;
    const std::vector<std::vector<Seat>>& getSeats() const;
    std::vector<std::string> getSelectedSeats() const;
};

#endif // AIRPLANE_H