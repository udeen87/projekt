#ifndef CONSOLE_UI_H
#define CONSOLE_UI_H

#include "Airplane.h"
#include <string>

class ConsoleUI {
private:
    Airplane& airplane;

    void displaySeats() const;
    void displaySelectedSeats() const;
    void handleSeatSelectionResult(SelectResult result, const std::string& seatId) const;
    void toUpperString(std::string& str) const;

public:
    ConsoleUI(Airplane& plane);


    void run();
};

#endif // CONSOLE_UI_H